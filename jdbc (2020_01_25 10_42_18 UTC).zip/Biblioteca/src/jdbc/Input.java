package jdbc;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.*;

public class Input{
    public Input(){
        menu = "---------------------MENU---------------------\nStiamo analizzando la tabella Lettore(tessera, nome, via, civico, citta)\nSeleziona l'operazione da eseguire.\n[1]INSERT\n[2]DELETE\n[3]UPDATE\n[4]VISUALIZZA TABELLA\n[5]EXIT";
    }

    //Restituisce stringa menu
    public String getMenu() {
        return menu;
    }

    //Mostra la tabella 
    public String showTable(Statement stmt) throws SQLException {
		String sql = "SELECT * FROM Lettore";
		ResultSet rs = stmt.executeQuery(sql);
		String result = "";
		while(rs.next()) {
			int tessera = rs.getInt("tessera");
			String nome = rs.getString("nome");
			String via = rs.getString("via");
			int civico = rs.getInt("civico");
			String citta = rs.getString("citta");
			result += tessera +": " + nome + " Indirizzo: " + via + ", "+ civico + ", " + citta + "\n";
		}
		rs.close();
		return result + "\n";
	}

    public String inputInsert(BufferedReader in) throws IOException{
        System.out.println("Inserisci nome e cognome");
		String nome = in.readLine();
		System.out.println("Inserisci via");
		String via = in.readLine();
		System.out.println("Inserisci civico");
    	String civico = in.readLine();
		System.out.println("Inserisci citt�");
		String citta = in.readLine();
        return "('" +nome + "', '" + via +"', " + civico+ ", '" + citta + "')";
    }

    public String inputDelete(BufferedReader in) throws IOException{
        System.out.println("Inserisci la tessera che vuoi eliminare");
		String tessera = in.readLine();
        return tessera;
    }

    public String inputUpdate(BufferedReader in) throws IOException{
        System.out.println("Quale tessera vuoi aggiornare?");
        String tessera = in.readLine();
        System.out.println("Quale campo vuoi aggiornare?");
		String up = in.readLine();
		System.out.println("Con quale valore?");
		String x = in.readLine();
        if(up.equals("tessera") || up.equals("civico"))
            return up + " = " + x + " WHERE tessera = " + tessera;
        return up + " = '" + x + "' WHERE tessera = " + tessera;
    }
				
	
    private String menu; 
}