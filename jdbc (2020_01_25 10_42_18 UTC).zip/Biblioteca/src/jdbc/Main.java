package jdbc;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/?user=root";
	
	static final String USER = "root";
	
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			Input input = new Input();

			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.print("Password: ");
			String pass = in.readLine();
			System.out.println("Connessione in corso ...");
			conn = DriverManager.getConnection(DB_URL, USER, pass);
			stmt = conn.createStatement();
			System.out.println("Connessione avvenuta con successo!");
			String sql = "use biblio";
			stmt.executeUpdate(sql);
			boolean done = false;
			String opzione;
			String x = "";
			while(!done) {
				System.out.println(input.getMenu());
				opzione = in.readLine().trim();
				switch (opzione) {
				case "1":
					x = input.inputInsert(in);
					sql = "INSERT INTO Lettore (nome, via, civico, citta) VALUES " + x;
					stmt.execute(sql);	
					System.out.println(input.showTable(stmt));
					break;
				case "2":
					x = input.inputDelete(in);
					sql = "DELETE FROM Lettore WHERE tessera = " + x;
					stmt.execute(sql);	
					System.out.println(input.showTable(stmt));
					break;
				case "3": 
					x = input.inputUpdate(in);
					sql = "UPDATE Lettore SET "+ x;
					stmt.executeUpdate(sql);
					System.out.println(input.showTable(stmt));
					break;
				case "4":
					System.out.println(input.showTable(stmt));
					break;
				case "5":
					System.out.println("Alla prossima!");
					done = true;
					in.close();
					break;
				default:
					System.out.println("Unexpected value: " + opzione);
				}
			}
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(stmt!= null)
					conn.close();
			}
			catch(SQLException se) {
				se.printStackTrace();
			}
		}
	}

}
